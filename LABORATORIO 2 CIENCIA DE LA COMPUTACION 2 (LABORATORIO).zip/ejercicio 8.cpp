/*8. Escribir un programa que genere la tabla de multiplicar de un n�mero introducido por 
	el teclado.
*/
#include <iostream>
using namespace std;

int main(int argc, char *argv[]) {
	int n;
	do{
		cout<<"Introduce un numero (este sera el numero que multiplicara );";
		cin>>n;
	} while((n<1)||(n>15)) ;
	for(int x=1;x<=15;x++){
		cout<<n<<"*"<<x<<"="<<n*x<<endl;
	}
	return 0;
}
