#include <iostream>
using namespace std;

int main(int argc, char *argv[]) {
	char primernombre[100];
	char apellidopaterno[100];
	char apellidomaterno[100];
	printf(" Ingrese su primer nombre: ");
	cin>> primernombre;
	printf(" Ingrese su apellido paterno: ");
	cin>> apellidopaterno;
	printf(" Ingrese su apellido materno: ");
	cin>> apellidomaterno;
	primernombre[0] = towlower(primernombre[0]);
	apellidomaterno[0] = towlower(apellidomaterno[0]);
	apellidopaterno[0] = towlower(apellidopaterno[0]);
	cout<<primernombre[0]<<apellidopaterno<<apellidomaterno[0]<<"@unsa.edu.pe";
	return 0;
}
