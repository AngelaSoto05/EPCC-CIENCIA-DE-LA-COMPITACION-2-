//7.Calcula el promedio de 3 notas para n estudiantes.
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
	
	int promedio(int n1, int n2, int n3);

struct seccion1{

	char nombre[10];
	int nota1;
	int nota2;
	int nota3;
	bool estatus;
};

main(){
	
	struct seccion1 estudiantescuc[100];
	
	int i,n,aprobados=0,reprobados=0;
	
	printf("Indique la cantidad de Estudiantes a promediar: ");
	scanf("%i", &n);
	printf("\n");
	
	for (i=1; i<=n; i++){
	
		printf("Indique su Nombre: " );
		scanf("%s", &estudiantescuc[i].nombre);
		printf("Indique Nota 1: " );
		scanf("%i", &estudiantescuc[i].nota1);
		printf("Indique Nota 2: " );
		scanf("%i", &estudiantescuc[i].nota2);
		printf("Indique Nota 3: " );
		scanf("%i", &estudiantescuc[i].nota3);
		
		if (promedio(estudiantescuc[i].nota1, estudiantescuc[i].nota2, estudiantescuc[i].nota3) > 11){
			
			printf(" Estudiante APROBADO con  ",promedio(estudiantescuc[i].nota1, estudiantescuc[i].nota2, estudiantescuc[i].nota3));
			printf("\n");
			estudiantescuc[i].estatus=1;
			aprobados++;
		}
		
		else {
			printf(" Estudiante REPROBADO con ",promedio(estudiantescuc[i].nota1, estudiantescuc[i].nota2, estudiantescuc[i].nota3));
			
			estudiantescuc[i].estatus=0;
			reprobados++;
		}
	}
	
	printf("\n Total de Estudiantes APROBADOS : %i", aprobados);
	printf("\n Total de Estudiantes REPROBADOS : %i", reprobados);
	
	getchar();
}
	
	int promedio(int n1, int n2, int n3){
		
		float prom;
		prom=(n1+n2+n3)/3;
		
		return prom;
	}
