/*6. Elabore un programa que calcule la serie de Fibonacci. La serie de Fibonacci es la 
sucesi�n de n�meros: 0, 1, 1, 2, 3, 5, 8, 13, 21, 34, ... Cada n�mero se calcula sumando 
los dos anteriores a �l.*/

#include <iostream> 
using namespace std; 

int main ()
{
	int n, x = 0, y = 1, z = 1;
	
	cout<<"Ingrese el numero de elementos: "; cin>>n;
	
	cout<<"1 ";
	for (int i = 1; i < n; i++)
	{
		z = x + y;
		cout<<z<<" ";
		x = y;
		y = z;
	}
	
	return 0;
}
