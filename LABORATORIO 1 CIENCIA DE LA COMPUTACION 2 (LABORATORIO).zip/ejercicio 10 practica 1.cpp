/*10. Escribir un programa que almacene 
la cadena de caracteres contrase�a en 
una variable, pregunte al usuario por la 
contrase�a hasta que introduzca la contrase�a
 correcta.*/
#include <iostream>
#include <string.h>
using namespace std;
int main(int argc, char *argv[]) {
	char Usuario[30];
	char Contrase�a[30];
	int n=10;
	bool f=false;
	while(n<=10 and f==false){
		system("cls");
		cout<<"USUARIO : ";
		cin.getline(Usuario,30);
		cout<<"Contrase�a : ";
		cin.getline(Contrase�a,30);
		n++;
		if(strlen(Contrase�a)>=7){
			if((strcmp(Contrase�a,CONTRASE�A)==0)&&(strcmp(Usuario,USUARIO)==0)){
			   f=true;
			}
		}
		else {
			cout<<"ERROR :LA CONTRASE�A DEBE TENER AL MENOS 7 CARACTERES";
			system(" pause");
		}
		
	}
	if (f=true){
		cout<<"Contrase�a correcta ,usted pudo entrar exitosamente"; 
		system(" pause");
	}
	else{
		cout <<"Error !! usted ingreso 10 veces ,pruebe mas tarde.";
		system(" pause");
	}
	return 0;
}

