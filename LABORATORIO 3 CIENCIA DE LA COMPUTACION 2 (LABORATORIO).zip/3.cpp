/*3. Hacer un programa que lee por teclado 
la fecha actual y la fecha de nacimiento de
 una persona y por medio de una funci�n calcule
 su edad en a�os, meses y d�as.
*/

#include <stdio.h>

main(){
	
	int DiaN, MesN, AnioN;
	int DiaH, MesH, AnioH;
	int Dia, Mes, Anio;
	
	printf("Ingrese Dia, Mes y A�o de nacimiento (Separados por un espacio): ");
	scanf("%d %d %d",&DiaN,&MesN,&AnioN);
	
	printf("Ingrese Dia, Mes y A�o del dia de hoy (Separados por un espacio): ");
	scanf("%d %d %d",&DiaH,&MesH,&AnioH);
	
	Anio = AnioH - AnioN;
	
	if(MesN > MesH){
		Anio = Anio - 1;
	}
	
	Mes = MesH - MesN;
	
	if(Mes < 0){
		Mes = 12 + Mes;
	}
	
	if(DiaN > DiaH){
		Mes = Mes - 1;
	}
	
	printf("\nA�os: %d Meses: %d",Anio,Mes);
	
} 
