//Escribir un programa que visualice en pantalla los n�meros m�ltiplos de 5 comprendidos entre 1 y 100
#include <iostream>
using namespace std;

#include <iostream> 
	using namespace std; 

int main () 
{ 
	for (int i = 1; i <= 100; i++)
	{
		if (i % 5 == 0)
		{ cout<< i << endl; }
	}
	
	return 0;
} 
