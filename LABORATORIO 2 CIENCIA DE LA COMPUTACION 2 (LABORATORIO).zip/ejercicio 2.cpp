//2. Calcule los primeros 50 n�meros primos y muestre el resultado en pantalla



#include <iostream>

#include <conio.h>

using namespace std;

int main(){
	
	int i=1,j,cont;
	
	while(i<=50){
		
		cont=0;
		j=1;
		while(j<=i){
			
			if(i%j==0){
				
				cont++;}j++;}
		
		if(cont==2){
			
			
			
			cout<<i<<endl;}
		
		i++; }
	

	
	getch();
	
	return 0;
}
