
/*4. Escriba un c�digo que solicite ingresar dos n�meros ?? y ??, tal que ?? < ??. Muestre 
	todos los n�meros primos que se encuentren entre el rango de valores, de no 
	encontrarse, mostrar el primo m�s cercano a ?? o ??.
*/
#include<iostream>
using namespace std;

int main()
{
	int b=0,n=0,c=0,c2=0,res=0,nc=0;
	cout<<"Introduce elprimer numero: "; 
	cin>>b;
	cout<<"Introduce el ultimo numero: "; 
	cin>>n;
	for(c=b;c<=n;c++)
	{
		for(c2=1;c2<=c;c2++)
		{
			res=c%c2;
			if(res==0)
			{
				nc=nc+1;
			}
		}
		if(nc==2)
		{
			cout<<" "<<c;
		}
		nc=0;
	}
}
