/*
2. Hacer un programa que lea por teclado un a�o, 
calcule y muestre si es bisiesto. Para realizar el
 c�lculo utiliza una funci�n llamada bisiesto. 
La funci�n bisiesto recibe el a�o le�do por teclado,
 comprueba si es o no bisiesto.*/
#include <iostream>
using namespace std;
int bisiesto(int);   
int main()
{
	int anio;
	cout<<"Introduce a"<<(char)164<<"o: ";
	cin >> anio;
	if(bisiesto(anio))  
		cout << "Bisiesto" << endl;
	else
		cout << "No es bisiesto" << endl;
	system("pause"); 
}
int bisiesto(int a)   
{
	if(a%4==0 and a%100!=0 or a%400==0)
		return 1;
	else
		return 0;
}
