
/*6. Elabore un c�digo que solicite un numero entre
 100 < x < 999 y muestre el resultado en binario.
*/
#include <iostream>
	
using namespace std;

int main()
{
	int decimal[20];
	int binario[20];
	int i;
	cout << "Escribe un valor entre 100 al 999 : ";
	cin >> decimal[0];
	
	for ( i=0; decimal[i]!=1; i++)
	{
		decimal [i+1]=decimal[i]/ 2;
		binario[i] = decimal[i] % 2;
		if (decimal[i+1]==1) binario [i+1]=1;
	}
	for (int m = i ; m >= 0; m--){
		cout << binario[m];
		
	}
	return 0;
	
}
