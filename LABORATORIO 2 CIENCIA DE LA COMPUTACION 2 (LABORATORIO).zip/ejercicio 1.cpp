//alumno:ANGELA SHIRLETH SOTO HUERTa
//SEGUNDO A�O
//1-Sumar todos los enteros pares desde 2 hasta 100.
#include <stdio.h>
using namespace std;

int main(int argc, char *argv[]) {
	int i ,suma=0;
	for(i=2;i<=100;i+=2){ 
		suma +=i;
		
	}
	printf("\n LA SUMA DE LOS NUMEROS PARES ES :%i",suma);
	return 0;
}

