/*3. Elabore un programa que solicite 
ingresar una hora del d�a (HH:MM en formato de
cadena), solicite un tiempo en minutos a
 agregar, y retorne la hora de finalizaci�n 
(el formato de salida debe de estar en AM 
o PM seg�n corresponda).*/
#include <iostream>
using namespace std;

int main(int argc, char *argv[]) {
	string hora;
	int h, m;
	int min;
	string zona="A.M.";
	cout<<"Ingrese la hora en HORAS:MINUTOS ";
	cin>>hora;
	cout<<"Minutos QUE QUIERE aUMENTAR ";
	cin>>min;
	h=(hora[0]-'0')*10+(hora[1]-'0');
	m=(hora[3]-'0')*10+(hora[4]-'0')+min;
	
	if(m>=60){
		h+=((m-m%60)/60);
		m=m%60;
	}
	
	if(h>=12){
		if(h==12)
			zona="P.M.";
		else if(h>=24){
			zona="A.M.";
			h-=24;
		}
		else{
			h-=12;
			zona="P.M.";
		}
	}
	
	cout<<"HORA RESULTANTE: "<<h<<":"<<m<<" "<<zona;
	
	return 0;
}
