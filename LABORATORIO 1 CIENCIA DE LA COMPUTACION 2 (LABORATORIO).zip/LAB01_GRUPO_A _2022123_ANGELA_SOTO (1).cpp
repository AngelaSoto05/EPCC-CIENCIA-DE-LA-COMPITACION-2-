//1-Escriba un codigo que solicicte al usuario ingresar dos numeros enteros y que ingrese el producto de ambos
/*#include <iostream>
using namespace std;

int main(int argc, char *argv[]) {
	int numero1,numero2,producto;
	printf("\n Ingrese un numero entero(entero): ");
	scanf("%d",&numero1);
	printf("\n Ingrese otro numero entero(entero): ");
	scanf("%d",&numero2);
	producto =numero1*numero2;
	printf("\n El producto es :%d",numero1*numero2);
    return 0;
}
*/
/*2.Escriba un c�digo que solicite el primer nombre 
	de una persona, el apellido paterno y el apellido
materno. Retornar su correo UNSA generado, el 
cual consiste de la primera letra del nombre, 
el apellido paterno completo, y la primera letra 
del apellido materno. (se agrega el dominio de la
  universidad al final).*/
/*
#include <iostream>
	using namespace std;

int main(int argc, char *argv[]) {
char nombre[100];
char llidopaterno[100];
char llidomaterno[100];
printf("\n Ingrese su primer nombre): ");
scanf("%d",&primernombre );
printf("\n Ingrese su apellido paterno: ");
scanf("%d",&apellidopaterno);
printf("\n Ingrese su apellido materno: ");
scanf("%d",&apellidomaterno);
primernombre[0] = towlower(primernombre[0]);
apellidomaterno[0] = towlower(apellidomaterno[0]);
apellidopaterno[0] = towlower(apellidopaterno[0]);
cout<<"Su correo es: \n"<<nombre[0]<<llidopaterno<<llidomaterno[0]<<"@unsa.edu.pe";
return 0;
}
/*5. Elabore un c�digo que reciba como entrada una secuencia de caracteres que
contiene un numero flotante y retorne el n�mero redondeado.
*/

/*
//sol 1
#include <cmath>
#include<iostream>
using namespace std;

int main()
{
	double numero;
	cout<<"Ingresar  un n�mero:";
	cin>>n;
	
	cout<<"El n�mero "<<n<<" redondeado es: "<<round(n);
	return 0;
}
*/

//sol2
/*
#include <iostream>
using namespace std;

int main(int argc, char *argv[]) {
int numero1;
printf("\n Ingrese un numero entero: ");
scanf("%d",&numero1);
double numero1;
cout<<"El n�mero "<<numero1<<" redondeado es: "<<round(numero1);
return 0;
}
*/
/*7. Elabore un algoritmo que lea por teclado dos
 n�meros enteros y determine si uno es divisor del otro.*/
/*#include <iostream>
using namespace std;

int main(int argc, char *argv[])
{
	int numero1,numero2,producto;
	printf("\n Ingrese un numero entero(entero): ");
	scanf("%d",&numero1);
	printf("\n Ingrese otro numero entero(entero): ");
	scanf("%d",&numero2);
	if (numero1%numero2==0){
		printf("\n Es divisor  de :%d",numero1);
	}
	else {
		printf("\n No es divisor  de :%d",numero1);
	}
	return 0;
}
/*
/*8. Escribir un programa que calcule la media de x cantidad
	n�meros introducidos por el teclado.
*/
/*
#include <iostream>
	using namespace std;
int main(int argc, char *argv[]) {
	
	float suma=0,num=-1,resultado;
	int contador =-1;
	while (num!=0) {
		cout<< "Num :";
		cin >>num;
		suma+=num;
		contador ++;
	}
	resultado=suma/contador;
	cout <<"RESULTADO :"<<resultado <<endl;
	return 0;
}*/
/*9. Escribir un programa que lea 10 datos desde el teclado 
y sume s�lo aquellos que sean negativos.*/
/*#include <iostream>
using namespace std;

int main(int argc, char *argv[]) {
	int A[10],n,i;
	int suma=0;
	int su=0;
	cout<<"Ingrese N� de elementos al arreglo"<<endl;
	cin>>n;
	for(i=1;i<=n;i++){
		cout<<"A["<<i<<"]= ";
		cin>>A[i];
	}
	cout<<"\n\n";
	cout<<"Mostrando el arreglo"<<endl;
	for(i=1;i<=n;i++){
		cout<<"\t"<<A[i];
	} 
	cout<<"\n\n";
	
	for(i=1;i<=n;i++){
		
		if(A[i]>0){
			suma=suma+A[i];
		}else{
			su=su+A[i];
		}
	}
	
	cout<<"la suma de los numeros negativos : "<<su<<endl;
	
	
	return 0;
}
*/
