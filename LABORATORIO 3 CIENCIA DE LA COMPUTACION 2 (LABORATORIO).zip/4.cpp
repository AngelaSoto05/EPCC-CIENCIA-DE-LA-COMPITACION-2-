/*4. Hacer un programa que desarrolle una funci�n, 
que genere en pantalla el listado de n�meros primos
 ubicados entre 1 hasta un numero x (x es ingresado 
por teclado).*/
#include <iostream>
using namespace std;
bool primo (int n){
	bool condicion;
	if(n !=1 && n!=0){
		for (int i=2 ;i<=n;i++){
			if(n%i==0){
			   if(n==i){
				condicion=true;
			   }
			   else{
				condicion=false;
				return condicion;
			   }
			}
		}
	}else condicion =false;
	return condicion;
}

int main(int argc, char *argv[]) {
	int n;
	cout<<"Ingrese hasta que numero quiere encontrar : "<<endl;
	cin>>n;
	for (int i=1 ;i<=n;i++) {
		if(primo(i)) cout<<i<<endl;
	}
	return 0;
}

