//10. Escribir un programa que pida al usuario una palabra y luego muestre por pantalla 
	//una a una las letras de la palabra introducida empezando por la �ltima


#include <iostream>

using namespace std;

int main(){
	
	string palb, invesa;
	int n;
	cout<<"Escribe una palabra: ";
	cin>>palb;
	n=palb.length();
	
	for(int i=n; i>=0; i--){
		invesa=invesa+palb.substr(i,1);
	}
	
	cout<<endl;
	cout<<"\nInvertida: "<<invesa;
	
}
