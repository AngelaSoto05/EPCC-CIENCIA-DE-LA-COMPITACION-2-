/*
    ESTUDIANTE ANGELA SHIRLETH SOTO HUERTA 
	Universidad Nacional de San Agust�n de Arequipa
	Escuela Profesional de Ciencia de la Computaci�n
	Curso: Ciencia de la Computaci�n II-SEGUNDO A�O
*/
/*1. Hacer un programa que sin usar la funci�n 
pow(), pero por medio de una funci�n, calcule la
 potencia de un n�mero (ambos n�meros ingresados por teclado).
*/
	

#include <stdio.h>
#include <math.h>
int main()
{
	int base, exponente, i, sol=1;
	printf("Programa para hacer potencias\n\n\n");
	printf("Introduce la base de la potencia: ");
	scanf("%i",&base);
	printf("\n\nIntroduce el exponente de la potencia: ");
	scanf("%i",&exponente);
	printf("\n\n");
	for (i=0;i<exponente;i++)
	{
		sol=sol*base;
		printf("(%d)",base,base,sol);
	}
	printf(" =%d",sol);
	printf("\n\nResultado: %d ^ %d = %d\n",base,exponente,sol);
	return 0;
}
