//Elabore un programa que lea n n�meros y determine cu�l es el mayor, el menor y la 
//media de los n�meros le�dos.	
#include <iostream> 
using namespace std; 

int main () 
{
	int n, num;
	int mayor =0;
	int menor=0;
	int sum=0 ;
	int media = 0;
	
	cout<<"Ingrese cuantos  numeros  va a ingresar"<<endl;
	cin>> n;
	
	for (int i = 1; i <= n; i++)
	{
		cout<<"Ingrese un numero: "; cin>>num;
		if(i == 1)
		{ mayor = menor = num;}
		if (num > mayor)
		{ mayor = num; }
		if (num < menor)
		{ menor = num; }
		sum += num;
	}
	
	media = sum / n;
	cout<<"El numero mayor es: "<<mayor<<endl;
	cout<<"El numero menor es: "<<menor<<endl;
	cout<<"La media total es: "<<media<<endl;
	
	return 0;
}
