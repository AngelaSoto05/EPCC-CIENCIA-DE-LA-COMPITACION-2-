/*4. Escriba un c�digo que solicite una cantidad de 
minutos espec�fica y muestre como
resultado la hora y fecha resultante tomando 
como referencia la hora y fecha actual y
restarle el tiempo indicado.*/

#include <iostream>
#include <ctime>
#include <time.h>
using namespace std;


int main(int argc, char *argv[]) {
	
	int hora,minutos,p;
	string ala="A.M.";
	cout<<"Minutos especificamente: ";
	cin>>minutos;
	
	time_t t = time(NULL);
	struct tm tiempoLocal = *localtime(&t);
	hora=tiempoLocal.tm_hour;
	p=tiempoLocal.tm_min;
	
	
	if(p-minutos<0){
		p=minutos-p;
		hora=hora-((p-p%60)/60+1);
		p=60-p%60;
		if(hora<0){
			hora=hora*-1;
			hora=24-hora%24;
		}
	} else
	   p-=minutos;
	
	if(hora>=12){
		if(hora==12)
			ala="P.M.";
		else if(hora>=24){
			ala="A.M.";
			hora-=24;
		}
		else{
			hora-=12;
			ala="P.M.";
		}
	}
	
	cout<<"HORA RESULTANTE: "<<hora<<"-"<< p <<" "<<ala;
	
	return 0;
}

